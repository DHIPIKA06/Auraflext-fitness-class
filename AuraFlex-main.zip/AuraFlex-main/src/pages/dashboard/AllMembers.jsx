import React from 'react';

const AllMembers = () => {
    return (
        <div>
            <h1 className='text-5xl text-center my-20 font-semibold'>Under Maintenance</h1>
        </div>
    );
};

export default AllMembers;