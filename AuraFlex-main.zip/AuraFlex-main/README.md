## AuraFlex - Fitness Tracker Website

Website: https://aura-flex.web.app/

# Website Features
- Single Page Application
- Login/Register system
- SignIn with Google using Firebase
- Client & Server Side using MongoDB
- CRUD operations to Create, Read, Update & Delete Items. 


